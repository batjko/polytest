core-meta
=========

See the [component page](http://polymer.github.io/core-meta) for more information.