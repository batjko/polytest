core-iconset-svg
=========

See the [component page](http://polymer.github.io/core-iconset-svg) for more information.
