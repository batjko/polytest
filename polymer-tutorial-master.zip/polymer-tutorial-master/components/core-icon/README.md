core-icon
=========

See the [component page](http://polymer.github.io/core-icon) for more information.
