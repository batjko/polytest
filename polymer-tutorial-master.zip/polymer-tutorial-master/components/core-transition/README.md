core-transition
===============
