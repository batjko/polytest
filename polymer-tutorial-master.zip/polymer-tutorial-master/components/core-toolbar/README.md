core-toolbar
============

See the [component page](http://polymer.github.io/core-toolbar) for more information.
