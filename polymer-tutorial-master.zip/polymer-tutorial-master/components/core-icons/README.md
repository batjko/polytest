core-icons
=========

See the [component page](http://polymer.github.io/core-icons) for more information.
